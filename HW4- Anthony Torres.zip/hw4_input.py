'''
A program that will ask a user to input the weight of a package and returns
the appropriate shipping charge of "The Fast Freight Shipping Company" along
with the total charge according to the given weight and rate per pound. 
'''

print("Fast Freight Shipping Company total shipping charge calculator: ")
pkgWeight = eval(input("Enter the weight of package in pounds here: "))

if pkgWeight <= 2 and pkgWeight >= 0:
      ratePerPound = 1.10
elif pkgWeight > 2 and pkgWeight <= 6:
    ratePerPound = 2.20
elif pkgWeight > 6 and pkgWeight <= 10:
    ratePerPound = 3.70
elif pkgWeight > 10:
    ratePerPound = 3.80
else:
    print("Invalid Package Weight.")

if pkgWeight > 0:
    totalCharge = pkgWeight * ratePerPound
    print(f"Rate per pound: ${ratePerPound:.2f}")
    print(f"Total charge: ${totalCharge:.2f}")
